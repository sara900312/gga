import React from 'react';
import { ArabicTextTest } from '@/components/test/ArabicTextTest';

const ArabicTextTestPage: React.FC = () => {
  return <ArabicTextTest />;
};

export default ArabicTextTestPage;
